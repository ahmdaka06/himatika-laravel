<ul class="menu-inner py-1 d-none-print">
    <!-- Dashboards -->
    <li class="menu-header small text-uppercase"><span class="menu-header-text">Menu Utama</span></li>
    <li class="menu-item <?php echo e(request()->is('/*') ? 'active' : ''); ?>">
        <a href="<?php echo e(url('/')); ?>" class="menu-link">
            <i class="menu-icon tf-icons bx bx-home-circle"></i>
            <div data-i18n="Basic">Halaman Utama</div>
        </a>
    </li>

    <li class="menu-header small text-uppercase"><span class="menu-header-text">Seminar</span></li>
    <li class="menu-item <?php echo e(request()->is('seminar/register') ? 'active' : ''); ?>">
        <a href="<?php echo e(url('/seminar/register')); ?>" class="menu-link">
            <i class="menu-icon tf-icons bx bx-credit-card-alt"></i>
            <div data-i18n="Basic">Pendaftaran Seminar</div>
        </a>
    </li>
    <li class="menu-item <?php echo e(request()->is('seminar/invoice') ? 'active' : ''); ?>">
        <a href="<?php echo e(url('/seminar/invoice')); ?>" class="menu-link">
            <i class="menu-icon tf-icons bx bx-search"></i>
            <div data-i18n="Basic">Cari Faktur</div>
        </a>
    </li>
    <!-- Layouts -->
    


</ul>
<?php /**PATH D:\laragon\www\himatika-laravel\resources\views/layouts/guest/partials/_sidebar_menu.blade.php ENDPATH**/ ?>
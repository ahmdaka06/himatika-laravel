<ul class="menu-inner py-1 d-none-print">
    <?php if(auth()->guard()->check()): ?>
    <!-- Dashboards -->
    <li class="menu-header small text-uppercase"><span class="menu-header-text">Menu Utama</span></li>
    <li class="menu-item <?php echo e(request()->is('dashboard') ? 'active' : ''); ?>">
        <a href="<?php echo e(route('user.dashboard.index')); ?>" class="menu-link">
            <i class="menu-icon tf-icons bx bx-home-circle"></i>
            <div data-i18n="Basic">Dashboard</div>
        </a>
    </li>
    <li class="menu-header small text-uppercase"><span class="menu-header-text">Peserta</span></li>
    <li class="menu-item <?php echo e(request()->is('dashboard/participants') || request()->is('dashboard/participants/*') ? 'active' : ''); ?>">
        <a href="<?php echo e(route('user.participant.index')); ?>" class="menu-link">
            <i class="menu-icon tf-icons bx bx-user"></i>
            <div data-i18n="Basic">Peserta</div>
        </a>
    </li>
    <li class="menu-header small text-uppercase"><span class="menu-header-text">Berita</span></li>
    <li class="menu-item <?php echo e(request()->is('dashboard/news') || request()->is('dashboard/news/*') ? 'active' : ''); ?>">
        <a href="<?php echo e(route('user.news.index')); ?>" class="menu-link">
            <i class="menu-icon tf-icons bx bx-user"></i>
            <div data-i18n="Basic">Berita</div>
        </a>
    </li>
    <li class="menu-header small text-uppercase"><span class="menu-header-text">Pengaturan Website</span></li>
    <li class="menu-item <?php echo e(request()->is('dashboard/website-config') || request()->is('dashboard/website-config/*') ? 'active' : ''); ?>">
        <a href="<?php echo e(route('user.website-config.indexGET')); ?>" class="menu-link">
            <i class="menu-icon tf-icons bx bx-user"></i>
            <div data-i18n="Basic">Pengaturan Website</div>
        </a>
    </li>
    <?php endif; ?>
    <!-- Layouts -->
    


</ul>
<?php /**PATH D:\laragon\www\himatika-laravel\resources\views/layouts/user/partials/_sidebar_menu.blade.php ENDPATH**/ ?>
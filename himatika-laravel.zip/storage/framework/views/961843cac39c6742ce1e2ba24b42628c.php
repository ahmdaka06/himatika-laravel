<aside id="layout-menu" class="layout-menu menu-vertical menu bg-menu-theme d-none-print">
    <div class="app-brand demo">
        <a href="<?php echo e(url('/')); ?>" class="app-brand-link">
            
            <span class="app-brand-text demo menu-text fw-bold text-uppercase">HIMATIKA</span>
        </a>

        <a href="javascript:void(0);"
            class="layout-menu-toggle menu-link text-large ms-auto d-block d-xl-none">
            <i class="bx bx-chevron-left bx-sm align-middle"></i>
        </a>
    </div>

    <div class="menu-inner-shadow"></div>

    <?php echo $__env->make('layouts.partials._sidebar_menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</aside>
<!-- / Menu -->
<?php /**PATH D:\laragon\www\himatika-laravel\resources\views/layouts/partials/_layout_menu.blade.php ENDPATH**/ ?>
<?php $__env->startSection('title'); ?>
<?php echo e($page['title']); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('styles'); ?>
<style>
    .divider {
        margin: 0 !important;
    }

    h5.strip:after,
    h5.strip:before {
        height: 4px;
        display: inline-block;
        content: ' ';
        position: absolute;
        margin-top: 38px;
        border-radius: 100px;
        background: var(--bs-primary);
    }

    h5.strip:before {
        width: 50px;
    }

    @media print {
        body {
            padding: 0;
            margin: 0;
        }

        .d-none-print {
            display: none;
        }

        * {
            color: #333 !important;
        }

        .card-print {
            max-width: 450px;
            margin: auto;
        }

        .card-print .card-title {
            text-align: center;
        }

        .content-main {
            padding-top: 0;
        }
    }

</style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<?php if(isset($invoice)): ?>
    <?php echo $__env->make('guest.seminar.partials._invoice._search', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('guest.seminar.partials._invoice._index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php else: ?>
    <?php echo $__env->make('guest.seminar.partials._invoice._search', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.guest.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\himatika-laravel\resources\views/guest/seminar/invoice.blade.php ENDPATH**/ ?>